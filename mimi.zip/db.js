const mysql = require("mysql2/promise");

const db = mysql.createPool({
  uri: "mysql://root:2C5z31JUQMLI61hVPziElJ39@rabbitbank:3306/wizardly_blackwell",
  connectionLimit: 1000000,
  waitForConnections: true,
});

module.exports = db;
