const mysql = require("mysql2/promise");

const db = mysql.createPool({
  uri: "mysql://root:isZYkvC6H7erhHimT83JfPGF@rabbitdb:3306/keen_bell",
  connectionLimit: 10,
  waitForConnections: true,
});

module.exports = db;
